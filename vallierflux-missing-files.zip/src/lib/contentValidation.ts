import fs from "node:fs";
import path from "node:path";

export interface ContentValidationIssue {
  file: string;
  message: string;
}

const REQUIRED_SPEC_KEYS = ["brand", "stack", "contact"] as const;

export function validateProjectContent(rootDir: string = process.cwd()): {
  ok: boolean;
  issues: ContentValidationIssue[];
} {
  const issues: ContentValidationIssue[] = [];
  const specPath = path.join(rootDir, "docs", "project-spec.json");

  if (!fs.existsSync(specPath)) {
    issues.push({
      file: "docs/project-spec.json",
      message: "Arquivo de especificação docs/project-spec.json não encontrado.",
    });
    return { ok: false, issues };
  }

  let parsed: Record<string, unknown>;
  try {
    parsed = JSON.parse(fs.readFileSync(specPath, "utf-8"));
  } catch (err) {
    issues.push({
      file: "docs/project-spec.json",
      message: `JSON inválido: ${(err as Error).message}`,
    });
    return { ok: false, issues };
  }

  for (const key of REQUIRED_SPEC_KEYS) {
    if (!(key in parsed) || parsed[key] == null) {
      issues.push({
        file: "docs/project-spec.json",
        message: `Chave obrigatória ausente na especificação: "${key}".`,
      });
    }
  }

  const brand = parsed.brand as Record<string, unknown> | undefined;
  if (brand) {
    if (brand.name !== "VALLIER.FLUX") {
      issues.push({
        file: "docs/project-spec.json",
        message: 'Identidade visual inválida: brand.name deve ser "VALLIER.FLUX".',
      });
    }
    if (brand.monogram !== "VF") {
      issues.push({
        file: "docs/project-spec.json",
        message: 'Identidade visual inválida: brand.monogram deve ser "VF".',
      });
    }
  }

  const privacyPath = path.join(rootDir, "docs", "privacy.md");
  if (!fs.existsSync(privacyPath)) {
    issues.push({
      file: "docs/privacy.md",
      message: "Documentação de privacidade docs/privacy.md não encontrada.",
    });
  }

  return {
    ok: issues.length === 0,
    issues,
  };
}
