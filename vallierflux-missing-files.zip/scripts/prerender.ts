import fs from "node:fs";
import path from "node:path";
import React from "react";
import { renderToString } from "react-dom/server";
import App from "../src/App";

function normalizeSiteUrl(raw?: string): string | null {
  if (!raw) return null;
  const trimmed = raw.trim().replace(/\/+$/, "");
  if (!trimmed.startsWith("https://")) return null;
  try {
    const parsed = new URL(trimmed);
    return parsed.origin;
  } catch {
    return null;
  }
}

async function prerender() {
  const distDir = path.resolve(process.cwd(), "dist");
  const indexPath = path.join(distDir, "index.html");

  if (!fs.existsSync(indexPath)) {
    throw new Error("dist/index.html não encontrado. Execute vite build antes do prerender.");
  }

  const template = fs.readFileSync(indexPath, "utf-8");
  const appHtml = renderToString(React.createElement(App));
  const siteUrl = normalizeSiteUrl(process.env.VITE_SITE_URL);

  const seoTags = siteUrl
    ? [
        `<meta name="robots" content="index, follow" />`,
        `<link rel="canonical" href="${siteUrl}/" />`,
        `<meta property="og:url" content="${siteUrl}/" />`,
      ].join("\n    ")
    : `<meta name="robots" content="noindex, nofollow" />`;

  let output = template.replace(
    /<div id="root"><\/div>/,
    `<div id="root">${appHtml}</div>`
  );

  if (output.includes("<!-- SEO_TAGS -->")) {
    output = output.replace("<!-- SEO_TAGS -->", seoTags);
  } else {
    output = output.replace("</head>", `    ${seoTags}\n  </head>`);
  }

  fs.writeFileSync(indexPath, output, "utf-8");

  if (siteUrl) {
    const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${siteUrl}/</loc>
    <changefreq>monthly</changefreq>
    <priority>1.0</priority>
  </url>
</urlset>
`;
    fs.writeFileSync(path.join(distDir, "sitemap.xml"), sitemap, "utf-8");
    console.log(`Prerender concluído com indexação ativa (${siteUrl}) e sitemap.xml gerado.`);
  } else {
    const robotsTxt = `User-agent: *\nDisallow: /\n`;
    fs.writeFileSync(path.join(distDir, "robots.txt"), robotsTxt, "utf-8");
    console.log("Prerender concluído em modo preview/noindex (VITE_SITE_URL ausente).");
  }
}

prerender().catch((err) => {
  console.error("Erro durante prerender:", err);
  process.exit(1);
});
